dependencies: python, pillow and django
**TESTED ONLY IN WINDOWS AS THIS IS THE ONLY OS I HAVE ACCESS TO FOR NOW**
Please watch the video for the visual demo and steps 

Step 1: open venv folder, then go to scripts and open command terminal
Step 2: type in "activate.bat" in the terminal to activate the virtual environment which
        has all the dependencies installed
Step 3: Go back to main folder where manage.py is from within the terminal(virtual environment)
Step 4: Type in "python manage.py runserver" this launches the server in the default location:
Step 5: Press login to add photos. Username: admin , password: admin
Step 6: Press on image_objects, then add objects as you normally would

Test images will already be added in the system. You will be able to add more.      