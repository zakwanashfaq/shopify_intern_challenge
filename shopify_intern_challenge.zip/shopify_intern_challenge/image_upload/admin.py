from django.contrib import admin

# Register your models here.
from django.contrib import admin

from .models import image_object

admin.site.register(image_object)