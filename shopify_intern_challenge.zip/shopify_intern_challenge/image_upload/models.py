from django.db import models

# Create your models here.
class image_object(models.Model):

    name_of_image = models.CharField(max_length=200)
    description = models.TextField(null=True)
    price = models.CharField(max_length=200, null=True)
    image_file = models.ImageField(null=True, blank=True)

    def __str__(self):
        return self.name_of_image

    def delete(self, using=None, keep_parents=False):
        self.image_file.storage.delete(self.image_file.name)
        super().delete()
