from django.shortcuts import render
from .models import *
# Create your views here.
from django.http import HttpResponse


def index(request):
    images = image_object.objects.all()
    return render(request, 'home.html', {"image_object": images})
